# Changelog

<!--next-version-placeholder-->

## v0.1.0 (03/01/2025)

- First release of `pycounts`!